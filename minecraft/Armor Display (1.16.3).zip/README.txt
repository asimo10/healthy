----------------------------------------------------------------------------------------------------
To install, put the "Armor Display (resource).zip" file in your resource packs folder
	%appdata%/.minecraft/resourcepacks/

You must enable the resource pack in-game for it to work.
----------------------------------------------------------------------------------------------------
The "Armor Display (data).zip" file must go to the "datapacks" folder in your world's folder. eg:
	"%appdata%/.minecraft/saves/My World/datapacks/

After putting the zip in the folder, no extra setup in-game is needed for the datapack.
----------------------------------------------------------------------------------------------------